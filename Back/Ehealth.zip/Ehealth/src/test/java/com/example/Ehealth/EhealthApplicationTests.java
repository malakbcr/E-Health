package com.example.Ehealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EhealthApplicationTests {

	@Test
	void contextLoads() {
	}

}
