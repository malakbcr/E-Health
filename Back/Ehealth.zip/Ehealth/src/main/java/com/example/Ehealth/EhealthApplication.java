package com.example.Ehealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EhealthApplication {

	public static void main(String[] args) {
		SpringApplication.run(EhealthApplication.class, args);
	}

}
