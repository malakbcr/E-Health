package com.example.Ehealth.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface pharmacistRepository extends userRepository {
}
