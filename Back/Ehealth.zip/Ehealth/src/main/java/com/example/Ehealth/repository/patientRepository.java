package com.example.Ehealth.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface patientRepository extends userRepository {
}
